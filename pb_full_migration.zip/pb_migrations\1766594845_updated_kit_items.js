/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1366492821")

  // add field
  collection.fields.addAt(1, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_893705475",
    "hidden": false,
    "id": "relation98176952",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "template_id",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "relation"
  }))

  // add field
  collection.fields.addAt(2, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_3071488795",
    "hidden": false,
    "id": "relation1166304858",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "product_id",
    "presentable": false,
    "required": true,
    "system": false,
    "type": "relation"
  }))

  // add field
  collection.fields.addAt(3, new Field({
    "autogeneratePattern": "",
    "hidden": false,
    "id": "text2148193425",
    "max": 0,
    "min": 0,
    "name": "slot_name",
    "pattern": "",
    "presentable": false,
    "primaryKey": false,
    "required": true,
    "system": false,
    "type": "text"
  }))

  // add field
  collection.fields.addAt(4, new Field({
    "hidden": false,
    "id": "bool2398086938",
    "name": "is_recommended",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "bool"
  }))

  // add field
  collection.fields.addAt(5, new Field({
    "hidden": false,
    "id": "number4101605491",
    "max": null,
    "min": null,
    "name": "display_order",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1366492821")

  // remove field
  collection.fields.removeById("relation98176952")

  // remove field
  collection.fields.removeById("relation1166304858")

  // remove field
  collection.fields.removeById("text2148193425")

  // remove field
  collection.fields.removeById("bool2398086938")

  // remove field
  collection.fields.removeById("number4101605491")

  return app.save(collection)
})
