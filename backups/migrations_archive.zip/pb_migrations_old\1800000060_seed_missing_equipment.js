/// <reference path="../pb_data/types.d.ts" />

/**
 * Migration: Seed Missing Equipment from Saad's Spreadsheet
 * 
 * After auditing existing migrations, these 4 items were confirmed missing:
 * - SWIT PB-S220S (Battery)
 * - SmallHD CINE 5 (Monitor)
 * - SWIT S-1071H (Monitor)
 * - Hollyland Cosmo C1 (Wireless Video)
 */

const ID_EQUIPMENT = "pbc_equipment00001";
const ID_CATEGORIES = "pbc_categories0001";

function slugify(text) {
    return text.toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .trim();
}

migrate((app) => {
    console.log("🚀 Starting missing equipment seed (4 items)...");

    const equipmentCollection = app.findCollectionByNameOrId(ID_EQUIPMENT);
    const categoriesCollection = app.findCollectionByNameOrId(ID_CATEGORIES);

    // Build category map
    const categoryRecords = app.findRecordsByFilter(categoriesCollection, "1=1", "", 100, 0);
    const categoryMap = {};
    for (const rec of categoryRecords) {
        categoryMap[rec.get("name")] = rec.id;
        // Also map by slug for flexibility
        categoryMap[rec.get("slug")] = rec.id;
    }
    console.log(`📦 Loaded ${Object.keys(categoryMap).length / 2} categories`);

    // Missing equipment items with image URLs
    const items = [
        // POWER / BATTERIES
        {
            name: "SWIT PB-S220S 220Wh Heavy Duty Battery",
            name_en: "SWIT PB-S220S 220Wh Heavy Duty Battery",
            name_fr: "Batterie SWIT PB-S220S 220Wh Haute Capacité",
            slug: "swit-pb-s220s",
            category: "Power",
            brand: "SWIT",
            description_en: "220Wh Heavy Duty IP54 Battery Pack with D-Tap and USB outputs. V-Mount design for professional video production. Supports 16.8A max output current.",
            description_fr: "Batterie 220Wh robuste IP54 avec sorties D-Tap et USB. Monture V pour production vidéo professionnelle. Supporte un courant de sortie max de 16.8A.",
            specs: {
                capacity: "220Wh",
                voltage: "14.4V",
                mount: "V-Mount",
                outputs: "D-Tap, USB",
                rating: "IP54"
            },
            image_url: "https://static.bhphoto.com/images/images500x500/1589388969_1562157.jpg"
        },
        // MONITORS
        {
            name: "SmallHD CINE 5 Touchscreen Monitor",
            name_en: "SmallHD CINE 5 Touchscreen Monitor",
            name_fr: "Moniteur Tactile SmallHD CINE 5",
            slug: "smallhd-cine-5",
            category: "Monitors",
            brand: "SmallHD",
            description_en: "5-inch touchscreen on-camera monitor with 1000 nit brightness, 1920x1080 resolution, and Page OS. Professional color accuracy with 3D LUT support.",
            description_fr: "Moniteur tactile 5 pouces avec luminosité de 1000 nits, résolution 1920x1080 et Page OS. Précision couleur professionnelle avec support 3D LUT.",
            specs: {
                size: "5 inch",
                resolution: "1920x1080",
                brightness: "1000 nits",
                os: "Page OS",
                inputs: "HDMI, SDI"
            },
            image_url: "https://static.bhphoto.com/images/images500x500/1649178159_1681604.jpg"
        },
        {
            name: "SWIT S-1071H 7\" HD-SDI/HDMI Monitor",
            name_en: "SWIT S-1071H 7\" HD-SDI/HDMI Monitor",
            name_fr: "Moniteur SWIT S-1071H 7\" HD-SDI/HDMI",
            slug: "swit-s-1071h",
            category: "Monitors",
            brand: "SWIT",
            description_en: "7-inch HD-SDI/HDMI LCD Monitor with waveform, vectorscope, and peaking functions for field monitoring. 1024x600 resolution with wide viewing angle.",
            description_fr: "Moniteur LCD 7 pouces HD-SDI/HDMI avec forme d'onde, vectorscope et fonctions de peaking pour monitoring terrain. Résolution 1024x600.",
            specs: {
                size: "7 inch",
                resolution: "1024x600",
                inputs: "HD-SDI, HDMI",
                features: "Waveform, Vectorscope, Peaking"
            },
            image_url: "https://static.bhphoto.com/images/images500x500/1423148251_1054174.jpg"
        },
        // WIRELESS VIDEO
        {
            name: "Hollyland Cosmo C1 Wireless Video System",
            name_en: "Hollyland Cosmo C1 Wireless Video System",
            name_fr: "Système Vidéo Sans Fil Hollyland Cosmo C1",
            slug: "hollyland-cosmo-c1",
            category: "Wireless Video",
            brand: "Hollyland",
            description_en: "SDI/HDMI Wireless Video Transmission System with 1000ft range, near-zero latency, and dual HDMI/SDI inputs. Professional cinema-grade transmission.",
            description_fr: "Système de transmission vidéo sans fil SDI/HDMI avec portée de 300m, latence quasi nulle et entrées HDMI/SDI doubles. Transmission de qualité cinéma.",
            specs: {
                range: "1000ft / 300m",
                latency: "<1ms",
                inputs: "HDMI, SDI",
                outputs: "HDMI, SDI",
                resolution: "1080p60"
            },
            image_url: "https://static.bhphoto.com/images/images500x500/1605543124_1600899.jpg"
        }
    ];

    let added = 0;
    let skipped = 0;

    for (const item of items) {
        // Check if already exists
        try {
            const existing = app.findFirstRecordByFilter(equipmentCollection, `slug = "${item.slug}"`);
            if (existing) {
                console.log(`⏭️ Skipping (exists): ${item.name}`);
                skipped++;
                continue;
            }
        } catch (e) {
            // Doesn't exist, proceed
        }

        // Find category ID
        let catId = categoryMap[item.category];
        if (!catId) {
            // Try lowercase
            catId = categoryMap[item.category.toLowerCase()];
        }
        if (!catId) {
            console.log(`⚠️ Category not found: ${item.category} - skipping ${item.name}`);
            continue;
        }

        // Download image
        let imageFile = null;
        if (item.image_url) {
            try {
                console.log(`📸 Downloading image for ${item.name}...`);
                imageFile = $filesystem.fileFromURL(item.image_url, 30);
            } catch (e) {
                console.log(`⚠️ Image download failed for ${item.name}: ${e}`);
            }
        }

        // Create record
        const record = new Record(equipmentCollection);
        record.set("name", item.name);
        record.set("name_en", item.name_en);
        record.set("name_fr", item.name_fr);
        record.set("slug", item.slug);
        record.set("brand", item.brand);
        record.set("category", catId);
        record.set("description", item.description_en);
        record.set("description_en", item.description_en);
        record.set("description_fr", item.description_fr);
        record.set("specs", JSON.stringify(item.specs));
        record.set("specs_en", JSON.stringify(item.specs));
        record.set("specs_fr", JSON.stringify(item.specs));
        record.set("stock_available", 1);
        record.set("is_featured", false);
        record.set("visibility", true);

        if (imageFile) {
            record.set("image", imageFile);
        }

        app.save(record);
        console.log(`✅ Added: ${item.name}`);
        added++;
    }

    console.log(`\n🎉 Migration complete! Added: ${added}, Skipped: ${skipped}`);

}, (app) => {
    console.log("⬇️ Rollback - no automatic action");
    // To rollback: manually delete items with these slugs:
    // swit-pb-s220s, smallhd-cine-5, swit-s-1071h, hollyland-cosmo-c1
});
