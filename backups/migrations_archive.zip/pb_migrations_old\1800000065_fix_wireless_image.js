/// <reference path="../pb_data/types.d.ts" />

/**
 * Migration: Fix Hollyland Cosmo C1 Image - Phase 4
 * 
 * The Hollyland Cosmo C1 record was created in previous migration
 * but image download failed. This tries an alternative image URL.
 */

const ID_EQUIPMENT = "pbc_equipment00001";

migrate((app) => {
    console.log("📡 Phase 4: Fixing Hollyland Cosmo C1 image...");

    const equipmentCollection = app.findCollectionByNameOrId(ID_EQUIPMENT);

    // Find Hollyland Cosmo C1 record
    let record;
    try {
        record = app.findFirstRecordByFilter(equipmentCollection, "slug = 'hollyland-cosmo-c1'");
    } catch (e) {
        console.log("⚠️ Hollyland Cosmo C1 not found, skipping...");
        return;
    }

    // Check if already has image
    const existingImage = record.get("image");
    if (existingImage && existingImage !== "") {
        console.log("⏭️ Already has image, skipping...");
        return;
    }

    // Try alternative image URL from the user's provided link
    const imageUrl = "https://www.bhphotovideo.com/images/fb/hollyland_hl_cosmo_c1_cosmo_c1_sdi_hdmi_wireless_1671905.jpg";

    try {
        console.log("📸 Downloading Hollyland Cosmo C1 image...");
        const imageFile = $filesystem.fileFromURL(imageUrl, 30);
        if (imageFile) {
            record.set("image", imageFile);
            app.save(record);
            console.log("✅ Image added to Hollyland Cosmo C1");
        }
    } catch (e) {
        console.log(`⚠️ Image download failed: ${e}`);
        console.log("ℹ️ Manual image upload required via admin UI");
    }

    console.log("🎉 Phase 4 complete!");

}, (app) => {
    console.log("⬇️ Rollback - no action");
});
