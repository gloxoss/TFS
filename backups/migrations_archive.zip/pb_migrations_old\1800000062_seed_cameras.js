/// <reference path="../pb_data/types.d.ts" />

/**
 * Migration: Seed Cameras - Phase 1
 * 
 * Items to add:
 * - ARRI ALEXA 35 Xtreme
 * - Sony FX6 Full-Frame Cinema Camera
 */

const ID_EQUIPMENT = "pbc_equipment00001";
const ID_CATEGORIES = "pbc_categories0001";

function slugify(text) {
    return text.toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .trim();
}

migrate((app) => {
    console.log("🎬 Phase 1: Seeding Cameras...");

    const equipmentCollection = app.findCollectionByNameOrId(ID_EQUIPMENT);
    const categoriesCollection = app.findCollectionByNameOrId(ID_CATEGORIES);

    // Find Cameras category
    let camerasCatId;
    try {
        const catRec = app.findFirstRecordByFilter(categoriesCollection, "name = 'Cameras' || slug = 'cameras'");
        camerasCatId = catRec.id;
    } catch (e) {
        console.log("⚠️ Cameras category not found, creating...");
        const newCat = new Record(categoriesCollection);
        newCat.set("name", "Cameras");
        newCat.set("slug", "cameras");
        newCat.set("icon", "video");
        app.save(newCat);
        camerasCatId = newCat.id;
    }

    const cameras = [
        {
            name: "ARRI ALEXA 35 Xtreme",
            name_en: "ARRI ALEXA 35 Xtreme",
            name_fr: "ARRI ALEXA 35 Xtreme",
            slug: "arri-alexa-35-xtreme",
            brand: "ARRI",
            description_en: "The ALEXA 35 Xtreme is a major revision of the industry's trusted workhorse—ALEXA 35, known for its superior image quality, ease of use, and reliable operation. Building on its predecessor's solid foundation, ALEXA 35 Xtreme introduces powerful new hardware, higher speeds for breathtaking slow-motion images, and the efficient ARRICORE codec.",
            description_fr: "L'ALEXA 35 Xtreme est une révision majeure du cheval de bataille de l'industrie—l'ALEXA 35, reconnue pour sa qualité d'image supérieure, sa facilité d'utilisation et sa fiabilité. S'appuyant sur les bases solides de son prédécesseur, l'ALEXA 35 Xtreme introduit un nouveau matériel puissant et des vitesses plus élevées.",
            specs: {
                max_resolution: "4608 × 3164",
                media_type: "CFast 2.0",
                sensor_size: "28.0 × 19.2 mm (Super 35)",
                dynamic_range: "14+",
                weight: "6.4 Kg",
                codec: "ProRes 4444 / 4444 XQ / 422 HQ, ARRIRAW",
                max_fps: "75 fps (4:3 / Open Gate), 120 fps (2K/HD)"
            },
            image_url: "https://cdn.theasc.com/20250731-2-arri-alexa-35-xtreme-enso-32-front-right82.jpg"
        },
        {
            name: "Sony FX6 Full-Frame Cinema Camera",
            name_en: "Sony FX6 Full-Frame Cinema Camera",
            name_fr: "Caméra Cinéma Plein Format Sony FX6",
            slug: "sony-fx6",
            brand: "Sony",
            description_en: "The FX6 Full-Frame Camera from Sony was developed to offer versatile, cine-style imaging in a truly compact form. With the ability to capture up to 15+ stops of dynamic range, Sony's S-Cinetone gamma for filmlike skin tones, and up to 10-bit, 4:2:2 XAVC-I recording, the FX6 is poised to both supplement your FX9 or VENICE capture and to nimbly take on documentary, gimbal, and drone shoots on its own.",
            description_fr: "La caméra Sony FX6 plein format offre une imagerie de style cinéma polyvalente dans un format vraiment compact. Avec la capacité de capturer plus de 15 stops de plage dynamique et le gamma S-Cinetone de Sony pour des tons de peau naturels.",
            specs: {
                max_resolution: "4096 × 2160 (DCI 4K)",
                media_type: "CFexpress Type A, SDXC (V90)",
                sensor_size: "35.6 × 23.8 mm",
                dynamic_range: "15+",
                weight: "0.89 Kg",
                codec: "XAVC-I, XAVC-Long GOP, XAVC-HS (H.265)",
                max_fps: "120 fps (4K), 240 fps (Full HD)"
            },
            image_url: "https://static.bhphoto.com/images/multiple_images/images500x500/1671614142_IMG_1901057.jpg"
        }
    ];

    let added = 0;
    for (const cam of cameras) {
        try {
            const existing = app.findFirstRecordByFilter(equipmentCollection, `slug = "${cam.slug}"`);
            if (existing) {
                console.log(`⏭️ Skipping (exists): ${cam.name}`);
                continue;
            }
        } catch (e) { }

        let imageFile = null;
        if (cam.image_url) {
            try {
                console.log(`📸 Downloading image for ${cam.name}...`);
                imageFile = $filesystem.fileFromURL(cam.image_url, 30);
            } catch (e) {
                console.log(`⚠️ Image download failed: ${e}`);
            }
        }

        const record = new Record(equipmentCollection);
        record.set("name", cam.name);
        record.set("name_en", cam.name_en);
        record.set("name_fr", cam.name_fr);
        record.set("slug", cam.slug);
        record.set("brand", cam.brand);
        record.set("category", camerasCatId);
        record.set("description", cam.description_en);
        record.set("description_en", cam.description_en);
        record.set("description_fr", cam.description_fr);
        record.set("specs", JSON.stringify(cam.specs));
        record.set("specs_en", JSON.stringify(cam.specs));
        record.set("specs_fr", JSON.stringify(cam.specs));
        record.set("stock_available", 1);
        record.set("is_featured", true);
        record.set("visibility", true);

        if (imageFile) {
            record.set("image", imageFile);
        }

        app.save(record);
        console.log(`✅ Added: ${cam.name}`);
        added++;
    }

    console.log(`🎉 Phase 1 complete! Added ${added} cameras.`);

}, (app) => {
    console.log("⬇️ Rollback - no action");
});
