/// <reference path="../pb_data/types.d.ts" />

/**
 * Migration: Create Kit Templates AND Slots for New Cameras
 * 
 * Creates:
 * - ARRI ALEXA 35 Xtreme Production Package template + slots
 * - Sony FX6 Production Package template + slots
 */

const ID_EQUIPMENT = "pbc_equipment00001";
const ID_CATEGORIES = "pbc_categories0001";
const ID_KIT_TEMPLATES = "pbc_kittemplates01";
const ID_KIT_SLOTS = "pbc_kitslots000001";

migrate((app) => {
    console.log("🔧 Creating kit templates and slots for new cameras...");

    const equipmentCollection = app.findCollectionByNameOrId(ID_EQUIPMENT);
    const categoriesCollection = app.findCollectionByNameOrId(ID_CATEGORIES);
    const kitTemplatesCollection = app.findCollectionByNameOrId(ID_KIT_TEMPLATES);
    const kitSlotsCollection = app.findCollectionByNameOrId(ID_KIT_SLOTS);

    // Build equipment slug->ID map
    const equipmentRecords = app.findRecordsByFilter(equipmentCollection, "1=1", "", 500, 0);
    const equipmentMap = {};
    for (const rec of equipmentRecords) {
        equipmentMap[rec.get("slug")] = rec.id;
    }

    // Build category map
    const categoryRecords = app.findRecordsByFilter(categoriesCollection, "1=1", "", 100, 0);
    const categoryMap = {};
    for (const rec of categoryRecords) {
        categoryMap[rec.get("name")] = rec.id;
        categoryMap[rec.get("slug")] = rec.id;
    }

    // ===== CREATE TEMPLATES AND SLOTS =====
    const templates = [
        {
            name: "ARRI ALEXA 35 Xtreme Production Package",
            main_product_slug: "arri-alexa-35-xtreme",
            base_price_modifier: -200,
            description: "Complete production package for the ARRI ALEXA 35 Xtreme with 120fps slow-motion capabilities.",
            slots: [
                { slot_name: "Lens Choice", category: "Lenses", recommended: ["cooke-s8i-ff-prime-set", "fujinon-zk25-300mm-cabrio"], display_order: 1 },
                { slot_name: "Monitor", category: "Monitors", recommended: ["smallhd-cine-5", "tvlogic-f-7hs"], display_order: 2 },
                { slot_name: "Wireless Video", category: "Wireless Video", recommended: ["hollyland-cosmo-c1"], display_order: 3 },
                { slot_name: "Power", category: "Power", recommended: ["bebob-v290rm-cine"], display_order: 4 }
            ]
        },
        {
            name: "Sony FX6 Production Package",
            main_product_slug: "sony-fx6",
            base_price_modifier: -100,
            description: "Compact cinema package for the Sony FX6. Ideal for documentary and run-and-gun shooting.",
            slots: [
                { slot_name: "Lens Choice", category: "Lenses", recommended: ["sony-fe-24-70mm-f28-gm-ii", "sony-fe-24-105mm-f4-g-oss"], display_order: 1 },
                { slot_name: "Monitor", category: "Monitors", recommended: ["smallhd-cine-5", "swit-s-1071h"], display_order: 2 },
                { slot_name: "Wireless Video", category: "Wireless Video", recommended: ["hollyland-cosmo-c1"], display_order: 3 },
                { slot_name: "Power", category: "Power", recommended: ["swit-pb-s220s"], display_order: 4 }
            ]
        }
    ];

    for (const tmpl of templates) {
        // Check if template exists
        let templateId;
        try {
            const existing = app.findFirstRecordByFilter(kitTemplatesCollection, `name = "${tmpl.name}"`);
            templateId = existing.id;
            console.log(`⏭️ Template exists: ${tmpl.name}`);
        } catch (e) {
            // Create template
            const mainProductId = equipmentMap[tmpl.main_product_slug];
            if (!mainProductId) {
                console.log(`⚠️ Main product not found: ${tmpl.main_product_slug}`);
                continue;
            }

            const templateRec = new Record(kitTemplatesCollection);
            templateRec.set("name", tmpl.name);
            templateRec.set("main_product_id", mainProductId);
            templateRec.set("base_price_modifier", tmpl.base_price_modifier);
            templateRec.set("description", tmpl.description);
            app.save(templateRec);
            templateId = templateRec.id;
            console.log(`✅ Created template: ${tmpl.name}`);
        }

        // Create slots
        for (const slot of tmpl.slots) {
            try {
                const existingSlot = app.findFirstRecordByFilter(kitSlotsCollection, `template_id = "${templateId}" && slot_name = "${slot.slot_name}"`);
                console.log(`⏭️ Slot exists: ${slot.slot_name}`);
                continue;
            } catch (e) { }

            const categoryId = categoryMap[slot.category];
            if (!categoryId) {
                console.log(`⚠️ Category not found: ${slot.category}`);
                continue;
            }

            const recommendedIds = slot.recommended
                .map(slug => equipmentMap[slug])
                .filter(id => id);

            const slotRec = new Record(kitSlotsCollection);
            slotRec.set("template_id", templateId);
            slotRec.set("slot_name", slot.slot_name);
            slotRec.set("category_id", categoryId);
            slotRec.set("recommended_ids", recommendedIds);
            slotRec.set("display_order", slot.display_order);
            app.save(slotRec);
            console.log(`✅ Created slot: ${slot.slot_name}`);
        }
    }

    console.log("🎉 Kit templates and slots created!");

}, (app) => {
    console.log("⬇️ Rollback - no action");
});
