/// <reference path="../pb_data/types.d.ts" />

/**
 * Migration: Seed Lenses - Phase 2
 * 
 * Items to add:
 * - Sony FE 14mm f/1.8 GM
 * - Sony FE 24-105mm f/4 G OSS
 * - Fujinon ZK25-300mm T3.5 Cabrio (PL)
 * - Tokina Cinema 50-135mm T3.0 (EF)
 * - Venus Optics LAOWA 24mm T14 PeriProbe (PL)
 * - Canon EJ T1.5 6mm B4-mount
 * - Canon EF 100mm f/2.8L Macro IS USM
 * - Canon TS-E 45mm f/2.8
 * - IB-E Lens Doubler PLx2
 */

const ID_EQUIPMENT = "pbc_equipment00001";
const ID_CATEGORIES = "pbc_categories0001";

function slugify(text) {
    return text.toLowerCase()
        .replace(/[^\w\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .trim();
}

migrate((app) => {
    console.log("🔭 Phase 2: Seeding Lenses...");

    const equipmentCollection = app.findCollectionByNameOrId(ID_EQUIPMENT);
    const categoriesCollection = app.findCollectionByNameOrId(ID_CATEGORIES);

    // Find Lenses category
    let lensesCatId;
    try {
        const catRec = app.findFirstRecordByFilter(categoriesCollection, "name = 'Lenses' || slug = 'lenses'");
        lensesCatId = catRec.id;
    } catch (e) {
        console.log("⚠️ Lenses category not found, creating...");
        const newCat = new Record(categoriesCollection);
        newCat.set("name", "Lenses");
        newCat.set("slug", "lenses");
        newCat.set("icon", "aperture");
        app.save(newCat);
        lensesCatId = newCat.id;
    }

    const lenses = [
        {
            name: "Sony FE 14mm f/1.8 GM",
            name_en: "Sony FE 14mm f/1.8 GM",
            name_fr: "Sony FE 14mm f/1.8 GM",
            slug: "sony-fe-14mm-f18-gm",
            brand: "Sony",
            description_en: "The FE 14mm F1.8 GM delivers incredible G Master quality and performance with a new perspective from an ultra-wide-angle field of view and bright F1.8 aperture -- all in a compact and lightweight design. Ideal for astrophotography, architecture, landscape, and even portraits and movie shooting.",
            description_fr: "Le FE 14mm F1.8 GM offre une qualité et des performances G Master exceptionnelles avec une perspective ultra grand-angle et une ouverture lumineuse F1.8 -- le tout dans un design compact et léger. Idéal pour l'astrophotographie, l'architecture et les paysages.",
            specs: {
                focal_length: "14mm",
                aperture: "f/1.8",
                mount: "Sony E",
                format: "Full-Frame",
                elements: "2 XA, 1 Aspherical, 2 ED, 1 Super ED"
            },
            image_url: "https://m.media-amazon.com/images/I/71FlYE88A2L._AC_UF894,1000_QL80_.jpg"
        },
        {
            name: "Sony FE 24-105mm f/4 G OSS",
            name_en: "Sony FE 24-105mm f/4 G OSS",
            name_fr: "Sony FE 24-105mm f/4 G OSS",
            slug: "sony-fe-24-105mm-f4-g-oss",
            brand: "Sony",
            description_en: "Designed for versatility, the FE 24-105mm f/4 G OSS Lens from Sony is a wide-angle to short-telephoto zoom designed to be an ideal one-lens solution for everyday shooting. The flexible focal length range pairs with a bright constant maximum aperture, impressive optics, and intuitive handling.",
            description_fr: "Conçu pour la polyvalence, le FE 24-105mm f/4 G OSS de Sony est un zoom grand-angle à court téléobjectif idéal comme solution mono-objectif pour la prise de vue quotidienne.",
            specs: {
                focal_length: "24-105mm",
                aperture: "f/4",
                mount: "Sony E",
                format: "Full-Frame",
                stabilization: "Optical SteadyShot"
            },
            image_url: "https://static.bhphoto.com/images/multiple_images/images500x500/1531399579_IMG_1026117.jpg"
        },
        {
            name: "Fujinon ZK25-300mm T3.5 Cabrio",
            name_en: "Fujinon ZK25-300mm T3.5 to T3.85 Cabrio Lens (PL Mount)",
            name_fr: "Objectif Fujinon ZK25-300mm T3.5 Cabrio (Monture PL)",
            slug: "fujinon-zk25-300mm-cabrio",
            brand: "Fujinon",
            description_en: "Spanning the Film and ENG worlds, and supporting 4K production, the Fujinon ZK25-300mm T3.5 to T3.85 Cabrio Lens is a 12x zoom for Super35 single-sensor cameras, and it features a PL mount. The long zoom range allows you to shoot medium-wide to long shots without changing lenses.",
            description_fr: "Alliant les mondes du cinéma et de l'ENG et supportant la production 4K, le Fujinon ZK25-300mm est un zoom 12x pour caméras Super35 avec monture PL. La longue plage de zoom permet de filmer du plan moyen au téléobjectif sans changer d'objectif.",
            specs: {
                focal_length: "25-300mm",
                aperture: "T3.5-T3.85",
                mount: "PL",
                format: "Super 35",
                zoom_ratio: "12x"
            },
            image_url: "https://static.bhphoto.com/images/images500x500/1623843470_1055313.jpg"
        },
        {
            name: "Tokina Cinema 50-135mm T3.0",
            name_en: "Tokina Cinema AT-X 50-135mm T/3 Lens (Canon EF Mount)",
            name_fr: "Objectif Tokina Cinema AT-X 50-135mm T/3 (Monture Canon EF)",
            slug: "tokina-cinema-50-135mm-t3",
            brand: "Tokina",
            description_en: "The Tokina Cinema 50-135mm T3.0 delivers a highly versatile zoom range in a compact design. Tokina engineers have created a lens that is Parfocal, which has dramatically reduced breathing and image shift, and a de-clicked, 9-bladed, curved iris for beautiful bokeh.",
            description_fr: "Le Tokina Cinema 50-135mm T3.0 offre une plage de zoom très polyvalente dans un design compact. Les ingénieurs Tokina ont créé un objectif parfocal avec une réduction drastique du breathing et du décalage d'image.",
            specs: {
                focal_length: "50-135mm",
                aperture: "T3.0",
                mount: "Canon EF",
                features: "Parfocal, 9-blade iris",
                close_focus: "1M"
            },
            image_url: "https://www.cathayphoto.com.sg/_next/image?url=https%3A%2F%2Fassets.cathayphoto.com.sg%2Fproduct%2Ftok-50-135-t3-cinema-_ef_.jpg&w=1920&q=75"
        },
        {
            name: "Venus Optics LAOWA 24mm T14 PeriProbe",
            name_en: "Venus Optics LAOWA 24mm T14-40 Full Frame 2x PeriProbe Cine Lens (PL Mount)",
            name_fr: "Objectif Ciné Venus Optics LAOWA 24mm T14 PeriProbe (Monture PL)",
            slug: "laowa-24mm-periprobe",
            brand: "Laowa",
            description_en: "The Venus Optics LAOWA 24mm T14-40 Full Frame 2x PeriProbe Cine Lens captures sharp magnified shots with full frame camera sensors using their ARRI PL-mount. Its periscope-style lens tube with interchangeable ends features an aperture range of T14 to T40. Use it underwater or in tight spaces, thanks to its waterproof front barrel.",
            description_fr: "L'objectif ciné Venus Optics LAOWA 24mm T14 PeriProbe capture des images nettes et magnifiées avec les capteurs plein format. Son tube périscope avec embouts interchangeables est étanche et idéal pour les espaces restreints.",
            specs: {
                focal_length: "24mm",
                aperture: "T14-T40",
                mount: "PL",
                format: "Full-Frame",
                features: "2x Macro, Waterproof front barrel"
            },
            image_url: "https://static.bhphoto.com/images/images500x500/1654688136_1710457.jpg"
        },
        {
            name: "Canon EJ T1.5 6mm B4-mount",
            name_en: "Canon EJ T1.5 6mm B4-mount Broadcast Lens",
            name_fr: "Objectif Broadcast Canon EJ T1.5 6mm Monture B4",
            slug: "canon-ej-6mm-t15-b4",
            brand: "Canon",
            description_en: "The Canon EJ 6mm T1.5 is an ultra-wide professional broadcast lens featuring a fast T1.5 aperture for excellent low-light performance. It delivers sharp, high-resolution images with accurate color, minimal distortion, and smooth focus operation, making it ideal for dynamic wide shots in live events, sports, and cinematic broadcast productions.",
            description_fr: "Le Canon EJ 6mm T1.5 est un objectif broadcast ultra grand-angle professionnel avec une ouverture rapide T1.5 pour d'excellentes performances en basse lumière. Il délivre des images nettes avec des couleurs précises et une distorsion minimale.",
            specs: {
                focal_length: "6mm",
                aperture: "T1.5",
                mount: "B4",
                format: "Broadcast 2/3\""
            },
            image_url: "https://media.exapro.com/product/2024/04/P240402264/595c32aab03f5ff7ce3717a00a678cc0/462x340/canon-ej-t15-p240402264_2.jpg"
        },
        {
            name: "Canon EF 100mm f/2.8L Macro IS USM",
            name_en: "Canon EF 100mm f/2.8L Macro IS USM",
            name_fr: "Canon EF 100mm f/2.8L Macro IS USM",
            slug: "canon-ef-100mm-f28l-macro",
            brand: "Canon",
            description_en: "Canon's newest 'L' series lens is its first mid-telephoto macro lens to include Canon's sophisticated Image Stabilization. With the highest quality optics available, combined with near-silent Ultrasonic focusing and life-size close-up capabilities without an adapter, the EF 100mm f/2.8L Macro IS USM is simply unrivalled.",
            description_fr: "Le premier objectif macro mi-téléobjectif de Canon à inclure la stabilisation d'image sophistiquée. Avec des optiques de la plus haute qualité, une mise au point ultrasonique quasi silencieuse et des capacités de macro 1:1 sans adaptateur.",
            specs: {
                focal_length: "100mm",
                aperture: "f/2.8",
                mount: "Canon EF",
                magnification: "1:1 Life-Size",
                stabilization: "Image Stabilization"
            },
            image_url: "https://mpex.com/_ipx/f_webp,b_%23fff,fit_contain,s_500x500/https://mpex.com/pub/media/catalog/product/cache/2264c9e38777ed202d5c3170a063a3cf/i/m/image_6230_4.jpg"
        },
        {
            name: "Canon TS-E 45mm f/2.8",
            name_en: "Canon TS-E 45mm f/2.8 Tilt-Shift Lens",
            name_fr: "Objectif Tilt-Shift Canon TS-E 45mm f/2.8",
            slug: "canon-tse-45mm-f28",
            brand: "Canon",
            description_en: "The TS-E 45mm f/2.8 is a tilt-shift lens that offers a field of view similar to that of a standard 50mm lens. The tilt-shift mechanisms provide complete control over depth of field and perspective.",
            description_fr: "Le TS-E 45mm f/2.8 est un objectif tilt-shift offrant un champ de vision similaire à un 50mm standard. Les mécanismes de bascule et de décentrement offrent un contrôle complet sur la profondeur de champ et la perspective.",
            specs: {
                focal_length: "45mm",
                aperture: "f/2.8",
                mount: "Canon EF",
                features: "Tilt-Shift, Perspective Control"
            },
            image_url: "https://i1.adis.ws/i/canon/2536A019_TS-E_45mm_f2.8_1?w=940&bg=rgb(245,246,246)&fmt=webp&qlt=100&sm=aspect&aspect=1:1"
        },
        {
            name: "IB-E Lens Doubler PLx2",
            name_en: "IB/E Optics PLx2 Lens Doubler (PL Mount)",
            name_fr: "Doubleur d'Objectif IB/E Optics PLx2 (Monture PL)",
            slug: "ibe-plx2-lens-doubler",
            brand: "IB/E Optics",
            description_en: "The deeper set optical assembly allows a greater range of spherical and anamorphic PL mount lenses to be used with this doubler. Optically, the PLx2 projects an image circle large enough to cover all commonly used 35mm formats including 5K on RED Epic and 4:3 full frame on ARRI Alexa.",
            description_fr: "L'assemblage optique plus profond permet d'utiliser une plus grande gamme d'objectifs sphériques et anamorphiques monture PL avec ce doubleur. Le PLx2 projette un cercle d'image assez grand pour couvrir tous les formats 35mm courants.",
            specs: {
                magnification: "2x",
                mount: "PL",
                max_image_diameter: "34.5mm",
                max_input_tstop: "T1.9"
            },
            image_url: "https://vmi.tv/wp-content/uploads/sites/3/2020/03/IBE-PLx2-Doubler.1.jpg"
        }
    ];

    let added = 0;
    for (const lens of lenses) {
        try {
            const existing = app.findFirstRecordByFilter(equipmentCollection, `slug = "${lens.slug}"`);
            if (existing) {
                console.log(`⏭️ Skipping (exists): ${lens.name}`);
                continue;
            }
        } catch (e) { }

        let imageFile = null;
        if (lens.image_url) {
            try {
                console.log(`📸 Downloading image for ${lens.name}...`);
                imageFile = $filesystem.fileFromURL(lens.image_url, 30);
            } catch (e) {
                console.log(`⚠️ Image download failed: ${e}`);
            }
        }

        const record = new Record(equipmentCollection);
        record.set("name", lens.name);
        record.set("name_en", lens.name_en);
        record.set("name_fr", lens.name_fr);
        record.set("slug", lens.slug);
        record.set("brand", lens.brand);
        record.set("category", lensesCatId);
        record.set("description", lens.description_en);
        record.set("description_en", lens.description_en);
        record.set("description_fr", lens.description_fr);
        record.set("specs", JSON.stringify(lens.specs));
        record.set("specs_en", JSON.stringify(lens.specs));
        record.set("specs_fr", JSON.stringify(lens.specs));
        record.set("stock_available", 1);
        record.set("is_featured", false);
        record.set("visibility", true);

        if (imageFile) {
            record.set("image", imageFile);
        }

        app.save(record);
        console.log(`✅ Added: ${lens.name}`);
        added++;
    }

    console.log(`🎉 Phase 2 complete! Added ${added} lenses.`);

}, (app) => {
    console.log("⬇️ Rollback - no action");
});
