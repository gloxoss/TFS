/// <reference path="../pb_data/types.d.ts" />

/**
 * Migration: Seed Monitors - Phase 3
 * 
 * Items to add:
 * - SWIT S-1051H 5" HD-SDI/HDMI Monitor
 * - RUIGE TL-701HDA 7" Monitor
 * - Lilliput FS7 7" 4K HDMI/3G-SDI Monitor
 * - TVLogic F-7HS 7" High Brightness Monitor
 * - SmallHD DP6-SDI 5.6" Monitor
 */

const ID_EQUIPMENT = "pbc_equipment00001";
const ID_CATEGORIES = "pbc_categories0001";

migrate((app) => {
    console.log("📺 Phase 3: Seeding Monitors...");

    const equipmentCollection = app.findCollectionByNameOrId(ID_EQUIPMENT);
    const categoriesCollection = app.findCollectionByNameOrId(ID_CATEGORIES);

    // Find Monitors category
    let monitorsCatId;
    try {
        const catRec = app.findFirstRecordByFilter(categoriesCollection, "name = 'Monitors' || slug = 'monitors'");
        monitorsCatId = catRec.id;
    } catch (e) {
        console.log("⚠️ Monitors category not found, creating...");
        const newCat = new Record(categoriesCollection);
        newCat.set("name", "Monitors");
        newCat.set("slug", "monitors");
        newCat.set("icon", "monitor");
        app.save(newCat);
        monitorsCatId = newCat.id;
    }

    const monitors = [
        {
            name: "SWIT S-1051H 5\" HD-SDI/HDMI Monitor",
            name_en: "SWIT S-1051H 5\" HD-SDI/HDMI Monitor",
            name_fr: "Moniteur SWIT S-1051H 5\" HD-SDI/HDMI",
            slug: "swit-s-1051h",
            brand: "SWIT",
            description_en: "Compact yet powerful, the SWIT S-1051H is a 5\" touchscreen on-camera monitor designed for professional filmmakers and cinematographers who need accuracy, reliability, and speed on set. Featuring a bright Full HD 1920×1080 display with excellent color fidelity.",
            description_fr: "Compact mais puissant, le SWIT S-1051H est un moniteur on-camera 5\" conçu pour les cinéastes professionnels. Écran Full HD 1920×1080 lumineux avec une excellente fidélité des couleurs.",
            specs: {
                size: "5 inch",
                resolution: "1920 x 1080",
                inputs: "HD-SDI, HDMI",
                features: "Waveform, Vectorscope, Peaking"
            },
            image_url: "https://static.bhphoto.com/images/multiple_images/images500x500/1452426413_IMG_573410.jpg"
        },
        {
            name: "RUIGE TL-701HDA 7\" Monitor",
            name_en: "RUIGE TL-701HDA 7\" LCD Monitor",
            name_fr: "Moniteur LCD RUIGE TL-701HDA 7\"",
            slug: "ruige-tl-701hda",
            brand: "RUIGE",
            description_en: "The new generation TL-701HDA LCD monitor is a high-resolution, wide-viewing angle, new-type A+ class LCD panel. The TL-701HDA combines three patented technologies for a multi-function professional LCD monitor that is widely used in film and field productions.",
            description_fr: "Le moniteur LCD TL-701HDA de nouvelle génération offre une haute résolution et un large angle de vision. Ce moniteur professionnel multifonction combine trois technologies brevetées et est largement utilisé en production cinématographique et de terrain.",
            specs: {
                size: "7 inch",
                panel: "A+ class LCD",
                viewing_angle: "Wide",
                features: "3 patented technologies"
            },
            image_url: "https://en.ruige.com/wp-content/uploads/2022/02/index01-2.jpg"
        },
        {
            name: "Lilliput FS7 7\" 4K HDMI/3G-SDI Monitor",
            name_en: "Lilliput FS7 7\" 4K HDMI/3G-SDI Monitor",
            name_fr: "Moniteur Lilliput FS7 7\" 4K HDMI/3G-SDI",
            slug: "lilliput-fs7",
            brand: "Lilliput",
            description_en: "The Lilliput FS7 7\" 4K HDMI/3G-SDI Monitor is a high-contrast on-camera monitor with a native 1920 x 1200, 8-bit resolution display. View clear, sharp images up to DCI 4K 4096 x 2160 via HDMI, and up to 1080p60 via the 3G-SDI input. The FS7 features a 1000:1 contrast ratio and 500 cd/m² brightness.",
            description_fr: "Le moniteur Lilliput FS7 7\" 4K est un moniteur on-camera haute contraste avec une résolution native 1920 x 1200. Visualisez des images nettes jusqu'en DCI 4K via HDMI et jusqu'en 1080p60 via l'entrée 3G-SDI.",
            specs: {
                size: "7 inch",
                resolution: "1920 x 1200",
                max_input: "DCI 4K 4096 x 2160 (HDMI)",
                contrast: "1000:1",
                brightness: "500 cd/m²",
                inputs: "HDMI, 3G-SDI"
            },
            image_url: "https://static.bhphoto.com/images/images500x500/1576780570_1412531.jpg"
        },
        {
            name: "TVLogic F-7HS 7\" High Brightness Monitor",
            name_en: "TVLogic F-7HS 7\" High Luminance LCD Field Monitor",
            name_fr: "Moniteur de Terrain TVLogic F-7HS 7\" Haute Luminosité",
            slug: "tvlogic-f-7hs",
            brand: "TVLogic",
            description_en: "The F-7HS 7\" Full HD Monitor is a High Brightness Field Monitor with Enhanced Sharpness, a 7\" 1920x1080 resolution field monitor that offers Max Brightness of 1800nits with enhanced sharpness and peaking boost function via the refined image processing engine.",
            description_fr: "Le moniteur F-7HS 7\" Full HD est un moniteur de terrain haute luminosité avec une netteté améliorée, une résolution 1920x1080 et une luminosité maximale de 1800 nits.",
            specs: {
                size: "7 inch",
                resolution: "1920 x 1080",
                brightness: "1800 nits Max",
                features: "Enhanced Sharpness, Peaking Boost"
            },
            image_url: "https://static.bhphoto.com/images/images500x500/1670343919_1737073.jpg"
        },
        {
            name: "SmallHD DP6-SDI 5.6\" Monitor",
            name_en: "SmallHD DP6-SDI 5.6\" Monitor",
            name_fr: "Moniteur SmallHD DP6-SDI 5.6\"",
            slug: "smallhd-dp6-sdi",
            brand: "SmallHD",
            description_en: "The SmallHD DP6 5.6\" Monitor is known as a lightweight, hi-res monitor with a highly accurate Focus Assist filter. The DP6 accepts HDMI, Component, and HD-SDI signals. Its simple interface provides easy navigation for its extensive menus.",
            description_fr: "Le moniteur SmallHD DP6 5.6\" est reconnu comme un moniteur léger et haute résolution avec un filtre Focus Assist très précis. Il accepte les signaux HDMI, Composante et HD-SDI.",
            specs: {
                size: "5.6 inch",
                inputs: "HDMI, Component, HD-SDI",
                features: "Focus Assist filter"
            },
            image_url: "https://www.talamas.com/sites/default/files/styles/large/public/smallhd-dp6-sdi-56-inch-monitor.jpg?itok=e8rBnTkR"
        }
    ];

    let added = 0;
    for (const mon of monitors) {
        try {
            const existing = app.findFirstRecordByFilter(equipmentCollection, `slug = "${mon.slug}"`);
            if (existing) {
                console.log(`⏭️ Skipping (exists): ${mon.name}`);
                continue;
            }
        } catch (e) { }

        let imageFile = null;
        if (mon.image_url) {
            try {
                console.log(`📸 Downloading image for ${mon.name}...`);
                imageFile = $filesystem.fileFromURL(mon.image_url, 30);
            } catch (e) {
                console.log(`⚠️ Image download failed: ${e}`);
            }
        }

        const record = new Record(equipmentCollection);
        record.set("name", mon.name);
        record.set("name_en", mon.name_en);
        record.set("name_fr", mon.name_fr);
        record.set("slug", mon.slug);
        record.set("brand", mon.brand);
        record.set("category", monitorsCatId);
        record.set("description", mon.description_en);
        record.set("description_en", mon.description_en);
        record.set("description_fr", mon.description_fr);
        record.set("specs", JSON.stringify(mon.specs));
        record.set("specs_en", JSON.stringify(mon.specs));
        record.set("specs_fr", JSON.stringify(mon.specs));
        record.set("stock_available", 1);
        record.set("is_featured", false);
        record.set("visibility", true);

        if (imageFile) {
            record.set("image", imageFile);
        }

        app.save(record);
        console.log(`✅ Added: ${mon.name}`);
        added++;
    }

    console.log(`🎉 Phase 3 complete! Added ${added} monitors.`);

}, (app) => {
    console.log("⬇️ Rollback - no action");
});
