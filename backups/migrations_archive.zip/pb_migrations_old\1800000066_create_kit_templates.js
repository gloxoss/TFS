/// <reference path="../pb_data/types.d.ts" />

/**
 * Migration: Create Kit Templates for New Cameras + Update Kit Slots
 * 
 * 1. Creates kit templates for:
 *    - ARRI ALEXA 35 Xtreme Production Package
 *    - Sony FX6 Production Package
 * 
 * 2. Adds new equipment to existing kit slots:
 *    - New lenses (Sony FE 14mm, Fujinon, Tokina, etc.)
 *    - New monitors (Lilliput, TVLogic F-7HS, etc.)
 *    - New wireless (Hollyland Cosmo C1)
 */

const ID_EQUIPMENT = "pbc_equipment00001";
const ID_CATEGORIES = "pbc_categories0001";
const ID_KIT_TEMPLATES = "pbc_kittemplates01";
const ID_KIT_SLOTS = "pbc_kitslots000001";

migrate((app) => {
    console.log("📦 Creating kit templates and updating kit slots...");

    const equipmentCollection = app.findCollectionByNameOrId(ID_EQUIPMENT);
    const categoriesCollection = app.findCollectionByNameOrId(ID_CATEGORIES);
    const kitTemplatesCollection = app.findCollectionByNameOrId(ID_KIT_TEMPLATES);
    const kitSlotsCollection = app.findCollectionByNameOrId(ID_KIT_SLOTS);

    // Build equipment slug->ID map
    const equipmentRecords = app.findRecordsByFilter(equipmentCollection, "1=1", "", 500, 0);
    const equipmentMap = {};
    for (const rec of equipmentRecords) {
        equipmentMap[rec.get("slug")] = rec.id;
    }
    console.log(`📦 Loaded ${Object.keys(equipmentMap).length} equipment items`);

    // Build category map
    const categoryRecords = app.findRecordsByFilter(categoriesCollection, "1=1", "", 100, 0);
    const categoryMap = {};
    for (const rec of categoryRecords) {
        categoryMap[rec.get("name")] = rec.id;
        categoryMap[rec.get("slug")] = rec.id;
    }

    // ===== 1. CREATE NEW KIT TEMPLATES =====
    const newTemplates = [
        {
            name: "ARRI ALEXA 35 Xtreme Production Package",
            main_product_slug: "arri-alexa-35-xtreme",
            base_price_modifier: -200,
            description: "Complete production package built around the ARRI ALEXA 35 Xtreme. Features enhanced slow-motion capabilities up to 120fps. Customize with your choice of lenses, support, monitoring, and accessories."
        },
        {
            name: "Sony FX6 Production Package",
            main_product_slug: "sony-fx6",
            base_price_modifier: -100,
            description: "Compact cinema package built around the Sony FX6. Ideal for documentary, gimbal, and run-and-gun shooting. Customize with your choice of Sony GM lenses, monitoring, and wireless."
        }
    ];

    const templateIds = {};

    for (const tmpl of newTemplates) {
        // Check if exists
        try {
            const existing = app.findFirstRecordByFilter(kitTemplatesCollection, `name = "${tmpl.name}"`);
            if (existing) {
                console.log(`⏭️ Template exists: ${tmpl.name}`);
                templateIds[tmpl.name] = existing.id;
                continue;
            }
        } catch (e) { }

        // Get main product ID
        const mainProductId = equipmentMap[tmpl.main_product_slug];
        if (!mainProductId) {
            console.log(`⚠️ Main product not found: ${tmpl.main_product_slug}`);
            continue;
        }

        const record = new Record(kitTemplatesCollection);
        record.set("name", tmpl.name);
        record.set("main_product_id", mainProductId);
        record.set("base_price_modifier", tmpl.base_price_modifier);
        record.set("description", tmpl.description);

        app.save(record);
        templateIds[tmpl.name] = record.id;
        console.log(`✅ Created template: ${tmpl.name}`);
    }

    // ===== 2. CREATE KIT SLOTS FOR NEW TEMPLATES =====
    const slotDefinitions = [
        // ALEXA 35 Xtreme Slots
        {
            template: "ARRI ALEXA 35 Xtreme Production Package",
            slot_name: "Lens Choice",
            category: "Lenses",
            required: true,
            recommended: [
                "cooke-s8i-ff-prime-set",
                "zeiss-supreme-prime-radiance-set",
                "fujinon-zk25-300mm-cabrio",
                "angenieux-optimo-45-120mm-t28"
            ],
            order: 1
        },
        {
            template: "ARRI ALEXA 35 Xtreme Production Package",
            slot_name: "Monitor",
            category: "Monitors",
            required: true,
            recommended: [
                "smallhd-cine-5",
                "tvlogic-f-7hs",
                "lilliput-fs7"
            ],
            order: 2
        },
        {
            template: "ARRI ALEXA 35 Xtreme Production Package",
            slot_name: "Wireless Video",
            category: "Wireless Video",
            required: false,
            recommended: [
                "hollyland-cosmo-c1",
                "hollyland-mars-400s-pro-ii"
            ],
            order: 3
        },
        {
            template: "ARRI ALEXA 35 Xtreme Production Package",
            slot_name: "Support",
            category: "Grip & Support",
            required: false,
            recommended: [
                "easyrig-vario-5",
                "tilta-armor-man-30"
            ],
            order: 4
        },
        {
            template: "ARRI ALEXA 35 Xtreme Production Package",
            slot_name: "Power",
            category: "Power",
            required: true,
            recommended: [
                "bebob-v290rm-cine",
                "idx-duo-c198p"
            ],
            order: 5
        },

        // Sony FX6 Slots
        {
            template: "Sony FX6 Production Package",
            slot_name: "Lens Choice",
            category: "Lenses",
            required: true,
            recommended: [
                "sony-fe-24-70mm-f28-gm-ii",
                "sony-fe-16-35mm-f28-gm",
                "sony-fe-70-200mm-f28-gm-oss",
                "sony-fe-24-105mm-f4-g-oss",
                "sony-fe-14mm-f18-gm"
            ],
            order: 1
        },
        {
            template: "Sony FX6 Production Package",
            slot_name: "Monitor",
            category: "Monitors",
            required: true,
            recommended: [
                "smallhd-cine-5",
                "swit-s-1071h",
                "lilliput-fs7"
            ],
            order: 2
        },
        {
            template: "Sony FX6 Production Package",
            slot_name: "Wireless Video",
            category: "Wireless Video",
            required: false,
            recommended: [
                "hollyland-cosmo-c1",
                "hollyland-mars-400s-pro-ii"
            ],
            order: 3
        },
        {
            template: "Sony FX6 Production Package",
            slot_name: "Support",
            category: "Grip & Support",
            required: false,
            recommended: [
                "easyrig-vario-5",
                "tilta-armor-man-30"
            ],
            order: 4
        },
        {
            template: "Sony FX6 Production Package",
            slot_name: "Power",
            category: "Power",
            required: false,
            recommended: [
                "swit-pb-s220s",
                "bebob-v200-micro"
            ],
            order: 5
        }
    ];

    for (const slot of slotDefinitions) {
        const templateId = templateIds[slot.template];
        if (!templateId) {
            console.log(`⚠️ Template not found: ${slot.template}`);
            continue;
        }

        // Check if slot exists
        try {
            const existing = app.findFirstRecordByFilter(kitSlotsCollection, `template_id = "${templateId}" && name = "${slot.slot_name}"`);
            if (existing) {
                console.log(`⏭️ Slot exists: ${slot.template} -> ${slot.slot_name}`);
                continue;
            }
        } catch (e) { }

        // Get category ID
        const categoryId = categoryMap[slot.category];

        // Get recommended equipment IDs
        const recommendedIds = [];
        for (const slug of slot.recommended) {
            if (equipmentMap[slug]) {
                recommendedIds.push(equipmentMap[slug]);
            }
        }

        const record = new Record(kitSlotsCollection);
        record.set("template_id", templateId);
        record.set("name", slot.slot_name);
        record.set("category", categoryId || null);
        record.set("required", slot.required);
        record.set("recommended_items", recommendedIds);
        record.set("order", slot.order);

        app.save(record);
        console.log(`✅ Created slot: ${slot.template} -> ${slot.slot_name} (${recommendedIds.length} recommendations)`);
    }

    // ===== 3. UPDATE EXISTING KIT SLOTS WITH NEW PRODUCTS =====
    console.log("\n📝 Updating existing kit slots with new products...");

    // Get all existing kit slots
    const allSlots = app.findRecordsByFilter(kitSlotsCollection, "1=1", "", 200, 0);

    const newLenses = [
        "sony-fe-14mm-f18-gm",
        "sony-fe-24-105mm-f4-g-oss",
        "fujinon-zk25-300mm-cabrio",
        "tokina-cinema-50-135mm-t3",
        "laowa-24mm-periprobe"
    ];

    const newMonitors = [
        "smallhd-cine-5",
        "swit-s-1071h",
        "ruige-tl-701hda",
        "lilliput-fs7",
        "tvlogic-f-7hs"
    ];

    const newWireless = [
        "hollyland-cosmo-c1"
    ];

    for (const slot of allSlots) {
        const slotName = slot.get("name");
        const existingRecs = slot.get("recommended_items") || [];
        let updated = false;
        let newRecs = [...existingRecs];

        // Add new lenses to Lens slots
        if (slotName && slotName.toLowerCase().includes("lens")) {
            for (const slug of newLenses) {
                const eqId = equipmentMap[slug];
                if (eqId && !newRecs.includes(eqId)) {
                    newRecs.push(eqId);
                    updated = true;
                }
            }
        }

        // Add new monitors to Monitor slots
        if (slotName && slotName.toLowerCase().includes("monitor")) {
            for (const slug of newMonitors) {
                const eqId = equipmentMap[slug];
                if (eqId && !newRecs.includes(eqId)) {
                    newRecs.push(eqId);
                    updated = true;
                }
            }
        }

        // Add new wireless to Wireless slots
        if (slotName && slotName.toLowerCase().includes("wireless")) {
            for (const slug of newWireless) {
                const eqId = equipmentMap[slug];
                if (eqId && !newRecs.includes(eqId)) {
                    newRecs.push(eqId);
                    updated = true;
                }
            }
        }

        if (updated) {
            slot.set("recommended_items", newRecs);
            app.save(slot);
            console.log(`📝 Updated slot: ${slotName} (+${newRecs.length - existingRecs.length} items)`);
        }
    }

    console.log("\n🎉 Kit templates and slots migration complete!");

}, (app) => {
    console.log("⬇️ Rollback - no action");
});
