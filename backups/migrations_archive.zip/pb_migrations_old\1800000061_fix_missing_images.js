/// <reference path="../pb_data/types.d.ts" />

/**
 * Migration: Fix Missing Equipment Images
 * 
 * The original B&H Photo URLs were blocked during the initial migration.
 * This migration attempts to add images using alternative sources.
 */

const ID_EQUIPMENT = "pbc_equipment00001";

migrate((app) => {
    console.log("🔧 Fixing missing equipment images...");

    const equipmentCollection = app.findCollectionByNameOrId(ID_EQUIPMENT);

    // Items with missing images and alternative URLs
    const fixes = [
        {
            slug: "hollyland-cosmo-c1",
            // Try Hollyland official CDN or Amazon
            image_urls: [
                "https://m.media-amazon.com/images/I/61dXpNDvCkL._AC_SL1280_.jpg",
                "https://cdn.shopify.com/s/files/1/0568/7496/0574/products/cosmo-c1_1024x1024.jpg"
            ]
        },
        {
            slug: "swit-pb-s220s",
            // Try SWIT official or Amazon
            image_urls: [
                "https://m.media-amazon.com/images/I/61fXhLfFqRL._AC_SL1500_.jpg",
                "https://cdn.shopify.com/s/files/1/0568/7496/0574/products/pb-s220s_1024x1024.jpg"
            ]
        }
    ];

    for (const fix of fixes) {
        try {
            const record = app.findFirstRecordByFilter(equipmentCollection, `slug = "${fix.slug}"`);
            if (!record) {
                console.log(`⚠️ Record not found: ${fix.slug}`);
                continue;
            }

            // Check if already has image
            const existingImage = record.get("image");
            if (existingImage && existingImage !== "") {
                console.log(`⏭️ Already has image: ${fix.slug}`);
                continue;
            }

            // Try each URL until one works
            let imageFile = null;
            for (const url of fix.image_urls) {
                try {
                    console.log(`📸 Trying: ${url.substring(0, 60)}...`);
                    imageFile = $filesystem.fileFromURL(url, 30);
                    if (imageFile) {
                        console.log(`✅ Image downloaded for ${fix.slug}`);
                        break;
                    }
                } catch (e) {
                    console.log(`⚠️ Failed: ${e}`);
                }
            }

            if (imageFile) {
                record.set("image", imageFile);
                app.save(record);
                console.log(`✅ Updated: ${fix.slug}`);
            } else {
                console.log(`❌ No working image URL for: ${fix.slug}`);
            }

        } catch (e) {
            console.log(`❌ Error fixing ${fix.slug}: ${e}`);
        }
    }

    console.log("🎉 Image fix migration complete!");

}, (app) => {
    console.log("⬇️ Rollback - no action");
});
